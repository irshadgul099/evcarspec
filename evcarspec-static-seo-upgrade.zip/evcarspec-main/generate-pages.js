// EVCarSpec static SEO page generator
// Run with: node generate-pages.js
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = __dirname;
const context = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, "evs-data.js"), "utf8"), context);
const db = context.window.EV_DATABASE || [];
if (!db.length) throw new Error("EV_DATABASE is empty; refusing to generate pages.");

const esc = v => String(v ?? "Not specified").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const slugify = v => String(v).toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
const pt = c => String(c.powertrain || "BEV").toUpperCase();
const site = "https://evcarspec.com";
const titleName = c => `${c.name} (${pt(c)}) Specifications, Battery, Range & Price`;
const baseCss = `
<style>
*{box-sizing:border-box}body{margin:0;background:#f8fafc;color:#1e293b;font:16px/1.6 Arial,sans-serif}
header{background:#0f172a;color:white;padding:16px 5%;display:flex;gap:18px;align-items:center;justify-content:space-between;flex-wrap:wrap}
.logo{font-size:24px;font-weight:900;color:#34d399;text-decoration:none}.logo span{color:#fff}
nav a,.chips a{color:#d1fae5;text-decoration:none;margin:0 8px;font-size:13px;font-weight:bold}
main{max-width:1120px;margin:28px auto;padding:0 18px}
.panel{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:24px;margin:18px 0;box-shadow:0 2px 8px #0f172a08}
h1{font-size:32px;line-height:1.2;margin:10px 0 14px;color:#0f172a}h2{font-size:22px;color:#0f172a;margin:0 0 14px}
p{color:#475569}.crumb{font-size:13px;color:#64748b}.crumb a,.link{color:#059669;text-decoration:none;font-weight:700}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.chips a{background:#ecfdf5;color:#047857;padding:6px 11px;border-radius:20px;margin:0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}
.stat,.card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:14px}
.stat small{display:block;color:#64748b}.stat strong{color:#0f172a}
table{width:100%;border-collapse:collapse}td{padding:10px;border-bottom:1px solid #e2e8f0;text-align:left}td:first-child{color:#64748b;width:38%}
.card a{color:#0f172a;font-weight:800;text-decoration:none}.card p{font-size:13px;margin:6px 0}
footer{background:#0f172a;color:#cbd5e1;text-align:center;padding:24px;margin-top:45px}footer a{color:#a7f3d0;margin:0 8px}
@media(max-width:600px){h1{font-size:25px}header{display:block}nav{margin-top:10px}}
</style>`;
function shell(title,desc,url,body,schema=""){
 return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} | EVCarSpec</title><meta name="description" content="${esc(desc).slice(0,155)}"><link rel="canonical" href="${site}${url}"><meta name="robots" content="index,follow">${baseCss}${schema}</head><body>
<header><a class="logo" href="/">EVCarSpec<span>.com</span></a><nav><a href="/">All EVs</a><a href="/category/suv/">SUVs</a><a href="/category/sedan/">Sedans</a><a href="/category/truck/">Trucks</a><a href="/category/bus/">Buses</a><a href="/category/scooter/">Scooters</a><a href="/category/bicycle/">Bicycles</a></nav></header>
<main>${body}</main><footer>© 2026 EVCarSpec.com — Independent Electric Vehicle Specifications Database.<br><a href="/about/">About</a><a href="/contact/">Contact</a><a href="/privacy-policy/">Privacy</a><a href="/terms/">Terms</a></footer></body></html>`;
}
const generated = [];
const urlFor = c => `/${c.slug.replace(/^\/+|\/+$/g,"")}/`;
function linkChip(label,url){return `<a href="${url}">${esc(label)}</a>`;}
function vehicleCard(c){
 return `<article class="card"><a href="${urlFor(c)}">${esc(c.name)}</a><p>${esc(c.brand)} · ${esc(c.category)} · ${pt(c)}</p><p><b>Battery:</b> ${esc(c.battery)}</p><p><b>Range:</b> ${esc(c.rangeText)}</p><p><b>US / India:</b> ${esc(c.prices?.us)} / ${esc(c.prices?.in)}</p><a class="link" href="${urlFor(c)}">View full specifications →</a></article>`;
}
function detail(c){
 const u=urlFor(c), brandUrl=`/brand/${slugify(c.brand)}/`, catUrl=`/category/${slugify(c.category)}/`, ptUrl=`/powertrain/${slugify(pt(c))}/`;
 const archUrl=`/architecture/${slugify(c.architecture||"unknown")}/`, chemUrl=`/chemistry/${slugify((c.chemistry||"unknown").split("/")[0].trim())}/`, driveUrl=`/drivetrain/${slugify(c.drive||"unknown")}/`;
 const chips=[linkChip(c.brand,brandUrl),linkChip(c.category,catUrl),linkChip(pt(c),ptUrl),linkChip(`${c.architecture||"Unknown"} Architecture`,archUrl),linkChip(`${c.chemistry||"Unknown"} Chemistry`,chemUrl),linkChip(`${c.drive||"Unknown"} Drivetrain`,driveUrl)].join("");
 const specs=[["Category",c.category],["Powertrain",pt(c)],["Battery",c.battery],["Usable battery",`${c.usableKwh??"Not specified"} kWh`],["Battery chemistry",c.chemistry],["Electrical architecture",c.architecture],["Official range",c.rangeText],["Estimated real-world range",c.realRange],["Efficiency",c.efficiency],["DC fast charging",c.dcChargeKw],["DC charging time",c.dcChargeTime],["AC charging",c.acChargeKw],["Acceleration",c.accel],["Power",c.power],["Torque",c.torque],["Top speed",c.topSpeed],["Drivetrain",c.drive],["Dimensions",c.dimensions],["Wheelbase",c.wheelbase],["Cargo / passenger capacity",c.bootSpace],["Weight",c.weight]];
 const prices=Object.entries(c.prices||{}).map(([k,v])=>`<div class="stat"><small>${esc(k.toUpperCase())}</small><strong>${esc(v)}</strong></div>`).join("");
 const related=db.filter(x=>x.slug!==c.slug && (x.brand===c.brand||x.category===c.category)).slice(0,8);
 const body=`<div class="crumb"><a href="/">Home</a> / <a href="${brandUrl}">${esc(c.brand)}</a> / <a href="${catUrl}">${esc(c.category)}</a> / ${esc(c.name)}</div>
 <section class="panel"><div class="chips">${chips}</div><h1>${esc(c.name)} — Full Specifications, Range & Global Price</h1><p>${esc(c.verdict)}</p>
 <div class="grid"><div class="stat"><small>Battery</small><strong>${esc(c.battery)}</strong></div><div class="stat"><small>Official range</small><strong>${esc(c.rangeText)}</strong></div><div class="stat"><small>Fast charging</small><strong>${esc(c.dcChargeKw)}</strong></div><div class="stat"><small>Acceleration</small><strong>${esc(c.accel)}</strong></div></div></section>
 <section class="panel"><h2>${esc(c.name)} Technical Specifications</h2><table>${specs.map(([k,v])=>`<tr><td>${esc(k)}</td><td><b>${esc(v)}</b></td></tr>`).join("")}</table></section>
 <section class="panel"><h2>Global Price Guide</h2><div class="grid">${prices}</div><p>Prices are indicative database entries and may vary by country, trim, taxes and model year. Verify with the manufacturer or local dealer before purchase.</p></section>
 <section class="panel"><h2>Key Strengths</h2><ul>${(c.pros||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h2>Limitations</h2><ul>${(c.cons||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul></section>
 <section class="panel"><h2>Related Electric Vehicles</h2><div class="grid">${related.map(vehicleCard).join("")}</div></section>`;
 const schema=`<script type="application/ld+json">${JSON.stringify({"@context":"https://schema.org","@type":"Vehicle","name":c.name,"brand":{"@type":"Brand","name":c.brand},"vehicleModelDate":undefined,"url":site+u,"description":c.verdict}).replace(/,"vehicleModelDate":undefined/,"")}</script>`;
 return shell(titleName(c),`${c.name}: battery ${c.battery}, range ${c.rangeText}, charging ${c.dcChargeKw}, global prices and full technical specifications.`,u,body,schema);
}
function collectionPage(kind,value,items){
 const slug=slugify(value), url=`/${kind}/${slug}/`;
 const names={brand:`${value} Electric Vehicles`,category:`Electric ${value}s`,powertrain:`${value} Electric Vehicles`,architecture:`${value} EV Architecture`,chemistry:`${value} Battery Chemistry`,drivetrain:`${value} Electric Vehicles with ${value} Drivetrain`};
 const title=names[kind]||`${value} EV Directory`;
 const description=`Browse ${items.length} ${title.toLowerCase()} with battery capacity, range, charging, specifications and global price information.`;
 const intro=`Explore ${items.length} electric vehicle ${items.length===1?"model":"models"} in this ${value} collection. Open any model for its technical specifications, battery information, range, charging details and indicative prices.`;
 const body=`<div class="crumb"><a href="/">Home</a> / ${esc(title)}</div><section class="panel"><h1>${esc(title)}</h1><p>${esc(intro)}</p><p>Compare battery capacity, driving range, charging capability, powertrain and available price information across the models listed below.</p></section><section class="panel"><h2>All ${esc(value)} Models (${items.length})</h2><div class="grid">${items.map(vehicleCard).join("")}</div></section><section class="panel"><h2>Explore More EV Collections</h2><div class="chips">${allCollectionLinks()}</div></section>`;
 const schema=`<script type="application/ld+json">${JSON.stringify({"@context":"https://schema.org","@type":"CollectionPage","name":title,"description":description,"url":site+url})}</script>`;
 const html=shell(title,description,url,body,schema);
 writePage(url,html);
}
function allCollectionLinks(){
 const links=[];
 for(const b of [...new Set(db.map(c=>c.brand))].sort()) links.push(linkChip(b,`/brand/${slugify(b)}/`));
 for(const c of [...new Set(db.map(c=>c.category))].sort()) links.push(linkChip(c,`/category/${slugify(c)}/`));
 for(const p of [...new Set(db.map(pt))].sort()) links.push(linkChip(p,`/powertrain/${slugify(p)}/`));
 for(const a of [...new Set(db.map(c=>c.architecture).filter(Boolean))].sort()) links.push(linkChip(`${a} Architecture`,`/architecture/${slugify(a)}/`));
 for(const ch of [...new Set(db.map(c=>(c.chemistry||"").split("/")[0].trim()).filter(Boolean))].sort()) links.push(linkChip(`${ch} Chemistry`,`/chemistry/${slugify(ch)}/`));
 for(const dr of [...new Set(db.map(c=>c.drive).filter(Boolean))].sort()) links.push(linkChip(`${dr} Drivetrain`,`/drivetrain/${slugify(dr)}/`));
 return links.join("");
}
function writePage(url,html){
 const dir=path.join(root,url.replace(/^\/|\/$/g,""));
 fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(path.join(dir,"index.html"),html);
 generated.push(site+url);
}
for(const c of db) writePage(urlFor(c),detail(c));
const dimensions=[
 ["brand",c=>c.brand],
 ["category",c=>c.category],
 ["powertrain",pt],
 ["architecture",c=>c.architecture],
 ["chemistry",c=>(c.chemistry||"").split("/")[0].trim()],
 ["drivetrain",c=>c.drive]
];
for(const [kind,get] of dimensions){
 const values=[...new Set(db.map(get).filter(Boolean))].sort();
 for(const value of values){
  const items=db.filter(c=>String(get(c)).toLowerCase()===String(value).toLowerCase());
  collectionPage(kind,value,items);
 }
}
// Add crawlable collection links to homepage while preserving its existing interactive filters.
const homePath=path.join(root,"index.html");
let home=fs.readFileSync(homePath,"utf8");
if(!home.includes('id="seoCollectionLinks"')){
 const section=`<section class="max-w-7xl mx-auto px-4 py-5"><div class="bg-white p-4 rounded-2xl border border-slate-200"><h2 class="text-sm font-extrabold text-slate-700 mb-3">Browse EV Collections</h2><div id="seoCollectionLinks" class="flex flex-wrap gap-2 text-xs"></div></div></section>`;
 home=home.replace('  <!-- Footer -->',section+'\n  <!-- Footer -->');
 const scriptTag=`<script>\n(function(){const db=window.EV_DATABASE||[];const box=document.getElementById('seoCollectionLinks');if(!box)return;const slug=s=>String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');const vals=[...new Set(db.map(x=>x.brand))].sort().map(x=>[x,'/brand/'+slug(x)+'/']).concat([...new Set(db.map(x=>x.category))].sort().map(x=>[x+'s','/category/'+slug(x)+'/']),[...new Set(db.map(x=>(x.powertrain||'BEV').toUpperCase()))].sort().map(x=>[x,'/powertrain/'+slug(x)+'/']),[...new Set(db.map(x=>x.architecture).filter(Boolean))].sort().map(x=>[x+' Architecture','/architecture/'+slug(x)+'/']),[...new Set(db.map(x=>(x.chemistry||'').split('/')[0].trim()).filter(Boolean))].sort().map(x=>[x+' Chemistry','/chemistry/'+slug(x)+'/']),[...new Set(db.map(x=>x.drive).filter(Boolean))].sort().map(x=>[x+' Drivetrain','/drivetrain/'+slug(x)+'/']));box.innerHTML=vals.map(([n,u])=>'<a class="px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-800 font-bold hover:bg-emerald-100" href="'+u+'">'+n+'</a>').join('');})();\n</script>\n`;
 home=home.replace('</body>',scriptTag+'</body>');
 fs.writeFileSync(homePath,home);
}
const staticUrls=["/","/about/","/contact/","/privacy-policy/","/terms/"];
const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${staticUrls.map(u=>`  <url><loc>${site+u}</loc></url>`).join("\n")}\n${generated.map(u=>`  <url><loc>${u}</loc></url>`).join("\n")}\n</urlset>\n`;
fs.writeFileSync(path.join(root,"sitemap.xml"),xml);
console.log(`Generated ${db.length} vehicle pages and ${generated.length-db.length} collection pages.`);
